# Flori Web Studio - Guide de Déploiement GitHub

Ce projet est une application React moderne construite avec Vite, Tailwind CSS et l'IA Gemini.

## 🚀 Comment déployer sur GitHub Pages

### 1. Exporter vers GitHub
Utilisez le menu **Settings > Export to GitHub** dans Google AI Studio pour créer votre dépôt.

### 2. Configuration locale (Optionnel)
Si vous clonez le projet sur votre ordinateur :
```bash
npm install
npm run build
```
Les fichiers prêts pour le web seront dans le dossier `dist/`.

### 3. Automatiser avec GitHub Actions
Pour que votre site se mette à jour tout seul :
1. Allez dans l'onglet **Settings** de votre dépôt GitHub.
2. **Pages** : Changez "Source" en "GitHub Actions".
3. Allez dans **Secrets and variables > Actions**.
4. Ajoutez un "New repository secret" nommé `GEMINI_API_KEY` avec votre clé d'API.

### 4. Support du Chatbot IA
Le chatbot utilise une clé d'API. Si vous hébergez le site en statique, la clé est injectée au moment du "build". 
**Attention** : Sur un site 100% statique comme GitHub Pages, votre clé est techniquement visible dans le code envoyé au navigateur. Pour un usage professionnel intensif, il est recommandé d'utiliser un petit serveur (Express) ou des Cloud Functions.

---
© 2024 Flori Web Studio
