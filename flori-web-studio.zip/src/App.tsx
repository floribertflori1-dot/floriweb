/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, ReactNode, useRef } from 'react';
import { 
  Layout, 
  ShoppingCart, 
  Zap, 
  RefreshCw, 
  Bot, 
  Smartphone, 
  Search, 
  Settings, 
  ExternalLink,
  ChevronRight,
  CheckCircle,
  Send,
  User,
  MessageSquare,
  X,
  PlusCircle,
  Image as ImageIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type Page = 'home' | 'about' | 'services' | 'portfolio' | 'testimonials' | 'quote' | 'contact';

export default function App() {
  const [activePage, setActivePage] = useState<Page>('home');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [testimonials, setTestimonials] = useState([
    {
      name: "Jean-Marc L.",
      company: "CEO @ Innovate Plus",
      quote: "Flori Web Studio a complètement révolutionné notre image de marque. L'intégration de l'IA a doublé notre taux de conversion.",
      photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=John"
    },
    {
      name: "Sarah M.",
      company: "Fondatrice @ GreenEat",
      quote: "Un design futuriste et une rapidité d'exécution incroyable. Mon site est désormais plus rapide sur mobile que sur desktop.",
      photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah"
    },
    {
      name: "Patrick K.",
      company: "Pasteur @ Église Lumière",
      quote: "La gestion de notre portail communautaire est devenue d'une simplicité déconcenrante. Merci Flori !",
      photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Patrick"
    }
  ]);

  const addTestimonial = (t: any) => {
    setTestimonials([t, ...testimonials]);
  };

  return (
    <div className="min-h-screen flex flex-col overflow-x-hidden relative">
      {/* Dynamic Background Glows */}
      <div className="fixed top-[-10%] right-[-10%] w-[600px] h-[600px] glow-indigo rounded-full pointer-events-none z-0" />
      <div className="fixed bottom-[-10%] left-[-10%] w-[500px] h-[500px] glow-purple rounded-full pointer-events-none z-0" />

      {/* Floating Chatbot */}
      <ChatBot isOpen={isChatOpen} setIsOpen={setIsChatOpen} />

      {/* BARRE DE NAVIGATION (FIXE) */}
      <nav className="glass-nav h-[80px] sticky top-0 flex-shrink-0 flex items-center z-50">
        <div className="max-w-7xl mx-auto w-full flex justify-between items-center px-12">
          <div 
            className="flex items-center gap-2 cursor-pointer group"
            onClick={() => setActivePage('home')}
          >
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center rotate-45 transition-transform group-hover:rotate-[135deg] duration-500">
              <div className="w-3 h-3 bg-white rounded-sm -rotate-45" />
            </div>
            <span className="text-xl font-extrabold tracking-tighter uppercase ml-2">
              FLORI<span className="text-indigo-500">WEB</span>
            </span>
          </div>
          
          {/* Menu */}
          <div className="flex items-center space-x-1 md:space-x-8">
            <NavButton 
              active={activePage === 'home'} 
              onClick={() => setActivePage('home')}
            >
              Accueil
            </NavButton>
            <NavButton 
              active={activePage === 'services'} 
              onClick={() => setActivePage('services')}
            >
              Services
            </NavButton>
            <NavButton 
              active={activePage === 'portfolio'} 
              onClick={() => setActivePage('portfolio')}
            >
              Portfolio
            </NavButton>
            <NavButton 
              active={activePage === 'testimonials'} 
              onClick={() => setActivePage('testimonials')}
            >
              Témoignages
            </NavButton>
            <NavButton 
              active={activePage === 'about'} 
              onClick={() => setActivePage('about')}
            >
              À Propos
            </NavButton>
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setActivePage('quote')}
                className={`hidden md:block px-6 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all border ${
                  activePage === 'quote' 
                  ? 'bg-white text-[#050508] border-white shadow-[0_0_20px_rgba(255,255,255,0.3)]' 
                  : 'bg-transparent text-white border-white/20 hover:bg-white/5'
                }`}
              >
                Devis Gratuit
              </button>
              <button 
                onClick={() => setActivePage('contact')}
                className={`hidden md:block px-6 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all ${
                  activePage === 'contact' 
                  ? 'bg-indigo-500 text-white shadow-[0_0_20px_rgba(79,70,229,0.4)]' 
                  : 'bg-indigo-600 text-white hover:bg-indigo-500 border border-indigo-400/30'
                }`}
              >
                Contact
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-grow flex flex-col relative z-10">
        <AnimatePresence mode="wait">
          {activePage === 'home' && (
            <PageWrapper key="home">
              <section className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-12 pt-20 px-12 md:items-center">
                <div className="md:col-span-12 lg:col-span-7 space-y-8">
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/10 border border-indigo-500/30 rounded-full"
                  >
                    <span className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">Solutions Digitales Futuristes</span>
                  </motion.div>
                  <motion.h1 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    className="text-5xl md:text-7xl font-black leading-[1.1] tracking-tight"
                  >
                    Ne vous contentez pas d'un site, <br />
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500">dominez votre marché.</span>
                  </motion.h1>
                  <motion.p 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="text-gray-400 text-lg md:text-xl leading-relaxed max-w-xl"
                  >
                    Flori Web Studio crée des plateformes digitales haut de gamme alliant Intelligence Artificielle et design haute performance.
                  </motion.p>
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="flex flex-col sm:flex-row gap-4"
                  >
                    <button 
                      onClick={() => setActivePage('portfolio')}
                      className="group bg-white text-[#050508] px-8 py-4 rounded-2xl font-bold text-lg hover:bg-indigo-50 transition-all flex items-center justify-center gap-2"
                    >
                      Voir le Portfolio
                      <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </button>
                    <button 
                      onClick={() => setActivePage('contact')}
                      className="border border-white/10 px-8 py-4 rounded-2xl font-bold hover:bg-white/5 transition-all text-gray-300 flex items-center justify-center"
                    >
                      Lancer un projet
                    </button>
                  </motion.div>
                </div>

                <div className="hidden lg:col-span-5 lg:flex flex-col gap-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-6 immersive-card rounded-[32px] group">
                      <div className="w-12 h-12 bg-indigo-500/20 rounded-2xl flex items-center justify-center mb-4 text-indigo-400 group-hover:scale-110 transition-transform">
                        <Smartphone className="w-6 h-6" />
                      </div>
                      <h3 className="font-bold text-lg mb-2">Web & Mobile</h3>
                      <p className="text-[10px] text-gray-500 leading-relaxed uppercase tracking-wider font-semibold">UI/UX Futuriste</p>
                    </div>
                    <div className="p-6 immersive-card rounded-[32px] group mt-8">
                      <div className="w-12 h-12 bg-purple-500/20 rounded-2xl flex items-center justify-center mb-4 text-purple-400 group-hover:scale-110 transition-transform">
                        <Bot className="w-6 h-6" />
                      </div>
                      <h3 className="font-bold text-lg mb-2">IA Intégrée</h3>
                      <p className="text-[10px] text-gray-500 leading-relaxed uppercase tracking-wider font-semibold">Automatisation</p>
                    </div>
                  </div>
                  
                  <div className="p-6 bg-gradient-to-br from-indigo-900/20 to-transparent border border-white/10 rounded-[32px] backdrop-blur-sm">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Trafic & Performance</span>
                      <span className="text-xs text-green-400 font-mono">+24.8% ↑</span>
                    </div>
                    <div className="flex items-end gap-1.5 h-16">
                      {[40, 60, 45, 80, 100, 70, 55].map((h, i) => (
                        <div 
                          key={i} 
                          className={`flex-1 rounded-t-lg transition-all duration-1000 delay-${i * 100}`}
                          style={{ 
                            height: `${h}%`, 
                            backgroundColor: i === 4 ? '#6366f1' : 'rgba(99, 102, 241, 0.3)',
                            boxShadow: i === 4 ? '0 -4px 12px rgba(79,70,229,0.4)' : 'none'
                          }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </section>
            </PageWrapper>
          )}

          {activePage === 'testimonials' && (
            <PageWrapper key="testimonials">
              <section className="max-w-6xl mx-auto pt-10 px-6 pb-20">
                <div className="text-center mb-16">
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="inline-block px-4 py-1 bg-indigo-500/10 border border-indigo-500/30 rounded-full mb-6"
                  >
                    <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-indigo-400">Ce que disent nos clients</span>
                  </motion.div>
                  <h2 className="text-3xl md:text-6xl font-black mb-4 uppercase tracking-tight">Témoignages</h2>
                  <p className="text-gray-400 text-lg max-w-2xl mx-auto">Ils nous font confiance pour propulser leur vision digitale dans le futur.</p>
                </div>

                <div className="mb-20">
                  <h3 className="text-xl font-bold mb-8 text-center uppercase tracking-widest text-white/60 flex items-center justify-center gap-3">
                    <PlusCircle className="w-5 h-5 text-indigo-500" />
                    Ajouter votre témoignage
                  </h3>
                  <div className="max-w-2xl mx-auto immersive-card rounded-[32px] p-8 border-indigo-500/20">
                    <TestimonialForm onAdd={addTestimonial} />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {testimonials.map((t, i) => (
                    <TestimonialCard 
                      key={i}
                      name={t.name}
                      company={t.company}
                      quote={t.quote}
                      photo={t.photo}
                    />
                  ))}
                </div>
              </section>
            </PageWrapper>
          )}

          {activePage === 'quote' && (
            <PageWrapper key="quote">
              <section className="max-w-4xl mx-auto pt-10 px-6 pb-20">
                <div className="text-center mb-12">
                  <h2 className="text-3xl md:text-5xl font-extrabold mb-4 uppercase tracking-tight">Demande de Devis</h2>
                  <p className="text-gray-400 text-lg">Décrivez votre projet et recevez une proposition chiffrée sous 24h.</p>
                </div>
                <div className="immersive-card rounded-[40px] p-8 md:p-12 border-indigo-500/20">
                  <QuoteForm />
                </div>
              </section>
            </PageWrapper>
          )}

          {activePage === 'about' && (
            <PageWrapper key="about">
              <section className="max-w-4xl mx-auto pt-10 px-6">
                <h2 className="text-3xl md:text-5xl font-extrabold mb-10 text-center uppercase tracking-tight">À Propos</h2>
                <div className="space-y-8 text-gray-300 text-lg md:text-xl leading-relaxed">
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="border-l-4 border-indigo-500 pl-6 py-2"
                  >
                    <p>Chez Flori Web Studio, nous créons des sites web modernes, professionnels et performants grâce à l’intelligence artificielle et aux dernières technologies du web.</p>
                  </motion.div>
                  <motion.p
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                  >
                    Notre mission est d’aider les entreprises, entrepreneurs, boutiques, églises et écoles à développer leur présence en ligne avec des sites attractifs, rapides et optimisés.
                  </motion.p>
                  <motion.p 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="text-white font-bold bg-indigo-600/10 p-6 rounded-2xl border border-indigo-500/20"
                  >
                    Nous combinons créativité, innovation et stratégie digitale pour livrer des sites web qui attirent des clients et augmentent la visibilité de votre activité.
                  </motion.p>
                </div>
              </section>
            </PageWrapper>
          )}

          {activePage === 'services' && (
            <PageWrapper key="services">
              <section className="max-w-6xl mx-auto pt-10 px-6 pb-20">
                <h2 className="text-3xl md:text-5xl font-extrabold mb-12 text-center uppercase tracking-tight">Nos Services</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <ServiceCard icon={Layout} title="Sites Vitrines" description="Présentez votre activité avec élégance." />
                  <ServiceCard icon={ShoppingCart} title="E-commerce" description="Vendez vos produits en toute sécurité." />
                  <ServiceCard icon={Zap} title="Landing Pages" description="Maximisez vos conversions de clients." />
                  <ServiceCard icon={RefreshCw} title="Refonte Web" description="Modernisez votre ancien site web." />
                  <ServiceCard icon={Bot} title="Assistés par IA" description="Vitesse de création révolutionnaire." />
                  <ServiceCard icon={Smartphone} title="Design Responsive" description="Adapté aux iPhones et Android." />
                  <ServiceCard icon={Search} title="Optimisation SEO" description="Soyez premier sur Google." />
                  <ServiceCard icon={Settings} title="Maintenance" description="Support technique et mises à jour." />
                </div>
              </section>
            </PageWrapper>
          )}

          {activePage === 'portfolio' && (
            <PageWrapper key="portfolio">
              <section className="max-w-6xl mx-auto pt-10 px-6 pb-20">
                <h2 className="text-3xl md:text-5xl font-extrabold mb-12 text-center uppercase tracking-tight">Réalisations</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <ProjectCard 
                    title="Luxe Gastronomie" 
                    description="Site web complet pour restaurant de luxe avec menu interactif et réservation WhatsApp."
                  />
                  <ProjectCard 
                    title="Nova School Portal" 
                    description="Portail digital éducatif pour la gestion des informations scolaires en temps réel."
                  />
                </div>
              </section>
            </PageWrapper>
          )}

          {activePage === 'contact' && (
            <PageWrapper key="contact">
              <section className="max-w-3xl mx-auto pt-10 px-6 text-center">
                <h2 className="text-3xl md:text-5xl font-extrabold mb-12 uppercase tracking-tight">Démarrons un projet</h2>
                <div className="space-y-6">
                  <motion.a 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    href="https://wa.me/243974437449" 
                    target="_blank"
                    className="block bg-[#25D366] p-8 rounded-3xl text-2xl font-black transition-all hover:shadow-[0_10px_30px_rgba(37,211,102,0.3)]"
                  >
                    WHATSAPP DIRECT
                  </motion.a>
                  <motion.a 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    href="mailto:floribertjean1@gmail.com" 
                    className="block bg-white text-black p-8 rounded-3xl text-xl font-bold transition-all hover:shadow-[0_10px_30px_rgba(255,255,255,0.2)]"
                  >
                    floribertjean1@gmail.com
                  </motion.a>
                </div>
                <footer className="mt-32 pb-20">
                  <p className="text-gray-600 font-mono text-[10px] uppercase tracking-[0.3em]">
                    © 2024 Flori Web Studio | Precision Development
                  </p>
                </footer>
              </section>
            </PageWrapper>
          )}
        </AnimatePresence>
      </main>

      {/* Global Status Footer */}
      <footer className="h-[60px] border-t border-white/5 flex items-center justify-between px-12 bg-transparent z-50">
        <div className="flex gap-12">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-tighter">System Online</span>
          </div>
          <div className="hidden md:block text-[10px] font-bold text-gray-500 uppercase tracking-tighter">
            Kinshasa, DRC & Paris, FR
          </div>
        </div>
        <div className="text-[10px] font-mono text-indigo-500/40 uppercase tracking-widest hidden sm:block">
          // STATUS_V2.0.BRUTALIST
        </div>
      </footer>
    </div>
  );
}

function NavButton({ children, active, onClick }: { children: ReactNode, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`relative text-[10px] md:text-xs font-bold uppercase tracking-widest px-2 py-1 transition-colors ${
        active ? 'text-indigo-500' : 'text-gray-400 hover:text-white'
      }`}
    >
      {children}
      {active && (
        <motion.div 
          layoutId="nav-underline"
          className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500"
        />
      )}
    </button>
  );
}

interface PageWrapperProps {
  children: ReactNode;
  key?: string;
}

function PageWrapper({ children }: PageWrapperProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -10 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="flex-grow pt-10"
    >
      {children}
    </motion.div>
  );
}

function ServiceCard({ icon: Icon, title, description }: { icon: any, title: string, description: string }) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="immersive-card rounded-[32px] p-8 text-center group"
    >
      <div className="bg-indigo-500/10 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 group-hover:bg-indigo-500/20 transition-all duration-500">
        <Icon className="text-indigo-500 w-8 h-8 group-hover:rotate-12 transition-transform" />
      </div>
      <h3 className="font-bold text-lg mb-2">{title}</h3>
      <p className="text-[11px] text-gray-500 leading-relaxed font-medium uppercase tracking-wider">{description}</p>
    </motion.div>
  );
}

function ProjectCard({ title, description }: { title: string, description: string }) {
  return (
    <motion.div 
      whileHover={{ scale: 1.01 }}
      className="immersive-card border-l-4 border-l-indigo-500 rounded-[32px] p-10 transition-all"
    >
      <h3 className="text-3xl font-black mb-4 tracking-tight">{title}</h3>
      <p className="text-gray-400 mb-8 max-w-md leading-relaxed">{description}</p>
      <a 
        href="https://github.com/floribertflori1-dot" 
        target="_blank" 
        rel="noopener noreferrer"
        className="inline-flex items-center gap-3 text-white bg-indigo-600/20 px-4 py-2 rounded-full border border-indigo-500/30 font-bold uppercase text-[10px] tracking-[0.2em] group hover:bg-indigo-600 hover:text-white transition-all"
      >
        Voir le projet 
        <ExternalLink className="w-3 h-3 transition-transform group-hover:translate-x-1" />
      </a>
    </motion.div>
  );
}

interface TestimonialCardProps {
  name: string;
  company: string;
  quote: string;
  photo: string;
  key?: any;
}

function TestimonialCard({ name, company, quote, photo }: TestimonialCardProps) {
  return (
    <motion.div 
      whileHover={{ scale: 1.02 }}
      className="immersive-card rounded-[32px] p-8 relative"
    >
      <div className="absolute top-6 right-8 text-indigo-500/20">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
          <path d="M14.017 21L14.017 18C14.017 16.8954 14.9124 16 16.017 16H19.017C20.1216 16 21.017 16.8954 21.017 18V21C21.017 22.1046 20.1216 23 19.017 23H16.017C14.9124 23 14.017 22.1046 14.017 21ZM3 21L3 18C3 16.8954 3.89543 16 5 16H8C9.10457 16 10 16.8954 10 18V21C10 22.1046 9.10457 23 8 23H5C3.89543 23 3 22.1046 3 21ZM16.017 3C19.3307 3 22.017 5.68629 22.017 9V14H16.017V9H19.017C19.017 7.34315 17.6738 6 16.017 6V3ZM5 3C8.31371 3 11 5.68629 11 9V14H5V9H8C8 7.34315 6.65685 6 5 6V3Z" />
        </svg>
      </div>
      <div className="flex items-center gap-4 mb-6">
        <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-indigo-500/30">
          <img src={photo} alt={name} className="w-full h-full object-cover" />
        </div>
        <div>
          <h4 className="font-bold text-white tracking-tight">{name}</h4>
          <p className="text-[10px] uppercase tracking-widest text-indigo-400 font-bold">{company}</p>
        </div>
      </div>
      <p className="text-gray-300 text-sm italic leading-relaxed">"{quote}"</p>
    </motion.div>
  );
}

function QuoteForm() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate submission
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1500);
  };

  if (submitted) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center py-20"
      >
        <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="text-green-500 w-10 h-10" />
        </div>
        <h3 className="text-3xl font-black mb-4">Demande Envoyée !</h3>
        <p className="text-gray-400 max-w-sm mx-auto mb-10">
          Merci ! Nous avons bien reçu votre demande. Notre équipe l'analyse et vous contactera sous 24 heures.
        </p>
        <button 
          onClick={() => setSubmitted(false)}
          className="text-indigo-400 font-bold uppercase text-xs tracking-[0.2em] border-b border-indigo-400/30 pb-1 hover:text-white transition-colors"
        >
          Envoyer une autre demande
        </button>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-2">
          <label className="text-[10px] uppercase tracking-widest font-bold text-gray-500 ml-4">Type de Projet</label>
          <select required className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:border-indigo-500 outline-none transition-all appearance-none text-white font-medium">
            <option value="" className="bg-[#050508]">Sélectionnez...</option>
            <option value="vitrine" className="bg-[#050508]">Site Vitrine</option>
            <option value="ecommerce" className="bg-[#050508]">E-commerce</option>
            <option value="app" className="bg-[#050508]">Application Web</option>
            <option value="refonte" className="bg-[#050508]">Refonte / Optimisation</option>
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-[10px] uppercase tracking-widest font-bold text-gray-500 ml-4">Budget Estimé</label>
          <select required className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:border-indigo-500 outline-none transition-all appearance-none text-white font-medium">
            <option value="" className="bg-[#050508]">Sélectionnez...</option>
            <option value="50" className="bg-[#050508]">Moins de 50 $</option>
            <option value="100" className="bg-[#050508]">50 $ - 100 $</option>
            <option value="200" className="bg-[#050508]">100 $ - 200 $</option>
            <option value="250" className="bg-[#050508]">Jusqu'à 250 $</option>
          </select>
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-[10px] uppercase tracking-widest font-bold text-gray-500 ml-4">Fonctionnalités Souhaitées</label>
        <textarea 
          required
          placeholder="Ex: Paiement en ligne, Blog, IA Chatbot, Espace client..."
          rows={4}
          className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:border-indigo-500 outline-none transition-all text-white placeholder:text-gray-600 font-medium"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-2">
          <label className="text-[10px] uppercase tracking-widest font-bold text-gray-500 ml-4">Nom Complet</label>
          <input required type="text" className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:border-indigo-500 outline-none transition-all text-white font-medium" />
        </div>
        <div className="space-y-2">
          <label className="text-[10px] uppercase tracking-widest font-bold text-gray-500 ml-4">Email Professionnel</label>
          <input required type="email" className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:border-indigo-500 outline-none transition-all text-white font-medium" />
        </div>
      </div>

      <div className="flex flex-col md:flex-row items-center justify-between gap-6 pt-4">
        <div className="flex items-center gap-3 text-gray-500">
          <CheckCircle className="w-5 h-5 text-indigo-500/50" />
          <span className="text-xs">Devis personnalisé gratuit et sans engagement</span>
        </div>
        <button 
          disabled={loading}
          type="submit"
          className="w-full md:w-auto bg-white text-black px-12 py-4 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-indigo-50 transition-all disabled:opacity-50 group"
        >
          {loading ? 'Envoi en cours...' : 'Envoyer ma demande'}
          <Send className={`w-5 h-5 transition-transform ${loading ? 'animate-pulse' : 'group-hover:translate-x-1 group-hover:-translate-y-1'}`} />
        </button>
      </div>
    </form>
  );
}

function TestimonialForm({ onAdd }: { onAdd: (t: any) => void }) {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    quote: '',
    photo: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newTestimonial = {
      ...formData,
      photo: formData.photo || `https://api.dicebear.com/7.x/avataaars/svg?seed=${formData.name || 'default'}`
    };
    onAdd(newTestimonial);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: '', company: '', quote: '', photo: '' });
    }, 3000);
  };

  if (submitted) {
    return (
      <div className="text-center py-4 text-green-400 font-bold flex items-center justify-center gap-2">
        <CheckCircle className="w-5 h-5" />
        Merci pour votre témoignage !
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <input 
          required 
          type="text" 
          placeholder="Votre Nom"
          value={formData.name}
          onChange={(e) => setFormData({...formData, name: e.target.value})}
          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:border-indigo-500 outline-none transition-all text-sm"
        />
        <input 
          required 
          type="text" 
          placeholder="Votre Entreprise / Poste"
          value={formData.company}
          onChange={(e) => setFormData({...formData, company: e.target.value})}
          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:border-indigo-500 outline-none transition-all text-sm"
        />
      </div>
      <textarea 
        required 
        placeholder="Votre témoignage..."
        rows={3}
        value={formData.quote}
        onChange={(e) => setFormData({...formData, quote: e.target.value})}
        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:border-indigo-500 outline-none transition-all text-sm"
      />
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-gray-500 text-xs">
          <ImageIcon className="w-4 h-4" />
          <span>Avatar généré automatiquement si vide</span>
        </div>
        <button 
          type="submit"
          className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold text-sm hover:bg-indigo-500 transition-all flex items-center gap-2"
        >
          Publier <Send className="w-4 h-4" />
        </button>
      </div>
    </form>
  );
}

function ChatBot({ isOpen, setIsOpen }: { isOpen: boolean, setIsOpen: (o: boolean) => void }) {
  const [messages, setMessages] = useState<{ role: 'user' | 'bot', text: string }[]>([
    { role: 'bot', text: "Bonjour ! Je suis l'assistant IA de Flori Web Studio. Comment puis-je vous aider aujourd'hui ?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim().toLowerCase();
    setMessages(prev => [...prev, { role: 'user', text: input.trim() }]);
    setInput('');
    setIsLoading(true);

    // Simulate thinking time
    setTimeout(() => {
      let botResponse = "Je suis ravi de vous aider ! Pour un devis précis ou une discusion directe, n'hésitez pas à nous contacter sur WhatsApp ou via le formulaire de devis.";
      
      if (userMsg.includes("prix") || userMsg.includes("coût") || userMsg.includes("tarif") || userMsg.includes("devis")) {
        botResponse = "Nos tarifs sont très compétitifs (jusqu'à 250$ pour les projets standards). Allez dans la section 'Devis Gratuit' pour une estimation précise !";
      } else if (userMsg.includes("services") || userMsg.includes("faites")) {
        botResponse = "Nous créons des sites vitrines, e-commerce, et des solutions assistées par IA. Tout est optimisé pour mobile et SEO.";
      } else if (userMsg.includes("contact") || userMsg.includes("whatsapp")) {
        botResponse = "Vous pouvez nous joindre directement sur WhatsApp via le bouton flottant ou dans la page Contact.";
      } else if (userMsg.includes("bonjour") || userMsg.includes("salut")) {
        botResponse = "Bonjour ! Comment Flori Web Studio peut-il booster votre présence digitale aujourd'hui ?";
      }

      setMessages(prev => [...prev, { role: 'bot', text: botResponse }]);
      setIsLoading(false);
    }, 800);
  };

  return (
    <>
      {/* Floating Bubble */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-24 right-8 w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center text-white shadow-2xl z-[100] cursor-pointer"
      >
        {isOpen ? <X className="w-8 h-8" /> : <MessageSquare className="w-8 h-8" />}
        <motion.span 
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute -top-1 -right-1 w-5 h-5 bg-purple-500 rounded-full border-2 border-[#050508] flex items-center justify-center text-[10px] font-bold"
        >
          AI
        </motion.span>
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            className="fixed bottom-44 right-8 w-[350px] md:w-[400px] h-[500px] immersive-card rounded-[32px] border-indigo-500/30 flex flex-col z-[100] overflow-hidden shadow-2xl"
          >
            {/* Header */}
            <div className="p-6 bg-indigo-600 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                  <Bot className="text-white w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">Assistant Flori AI</h3>
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-[10px] font-bold text-white/70 uppercase">Online</span>
                  </div>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-white/60 hover:text-white transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-grow p-6 overflow-y-auto space-y-4">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-4 rounded-2xl text-xs md:text-sm leading-relaxed ${
                    msg.role === 'user' 
                    ? 'bg-indigo-600 text-white rounded-tr-none shadow-lg' 
                    : 'bg-white/5 border border-white/10 text-gray-300 rounded-tl-none'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white/5 border border-white/10 text-gray-300 p-4 rounded-2xl rounded-tl-none animate-pulse">
                    En train de réfléchir...
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-6 border-t border-white/5 bg-black/20">
              <div className="relative">
                <input 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Posez votre question..."
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 pr-14 focus:border-indigo-500 outline-none transition-all text-sm text-white"
                />
                <button 
                  onClick={handleSend}
                  disabled={isLoading || !input.trim()}
                  className="absolute right-2 top-2 w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white hover:bg-indigo-500 transition-all disabled:opacity-50"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
